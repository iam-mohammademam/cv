const body = document.querySelector('body');
let buttons = document.querySelectorAll('.button');
// console.log(e.target)

for (var btn of buttons) {
	btn.addEventListener('click', (e) => {
		document.querySelector('.active').classList.remove('active');
	  
		let target = e.target,
			dataColor = target.getAttribute('data-color'),
			root = document.querySelector(':root'),
		  color = dataColor.split(' ') ;
	  target.classList.add('active');
		  
		  
		root.style.setProperty('--theme', color[0]);
		// console.log(e.target)

	})
}